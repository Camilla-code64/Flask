from flask import Flask, render_template

app = Flask(__name__)

'''@app.route("/")
def home():
    return "<h1>Minha primeira aplicação Flask</h1>"

@app.route("/sobre")
def sobre():
    return "<h1>Sobre a aplicação</h1>"

@app.route("/contato")
def contato():
    return "<h1>Contato</h1>"

@app.route("/aluno/<nome>")
def aluno(nome):
    return f"<h1>Olá, {nome}!</h1>"'''

@app.route("/")
def home():
    return render_template("1index.html")

@app.route("/aluno/<nome>")
def aluno(nome):
    return render_template("1aluno.html", nome=nome)

@app.route("/aluno")
@app.route("/aluno/<nome>")
def exibir_aluno(nome="Visitante"):
    return render_template("1aluno.html", nome=nome)

if __name__ == "__main__":
    app.run(debug=True)


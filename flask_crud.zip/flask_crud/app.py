from flask import Flask, render_template, request, redirect, url_for
from banco import conectar

app = Flask(__name__)

@app.route("/")
def home():

    conn = conectar()

    alunos = conn.execute("""
        SELECT *
        FROM alunos
        ORDER BY id DESC
""").fetchall()

    conn.close()

    return render_template("index.html", alunos=alunos)

@app.route("/cadastrar", methods=["POST"])
def cadastrar():

    nome = request.form["nome"]
    email = request.form["email"]
    curso = request.form["curso"]
    ra = request.form["ra"]

    conn = conectar()

    conn.execute("""
        INSERT INTO alunos
        (nome, email, curso, ra)
        VALUES (?, ?, ?, ?)
    """, (nome, email, curso, ra))

    conn.commit()

    conn.close()

    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)